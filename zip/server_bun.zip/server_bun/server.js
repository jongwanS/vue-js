// 기존 Node.js + Express 코드와 거의 동일하지만, 실행 환경만 Bun으로 바뀐 버전입니다! 

import express from "express";
import cors from "cors";

const port = 4500;
const app = express();

let nextId = 4;

let todos = [
  { id: 1, item: "Todo1", completed: false },
  { id: 2, item: "Todo2", completed: false },
  { id: 3, item: "Todo3", completed: true },
];

let posts = [
  { id: 1, email: "Sincere@april.biz", title: "Stores are as familiar as components." },
  { id: 2, email: "Shanna@melissa.tv", title: "Build multiple stores and let your bundler code split them automatically." },
  { id: 3, email: "Nathan@yesenia.net", title: "Proper TypeScript support or autocompletion for JS users" },
];

app.use(express.static('public'));
app.use(express.json());
app.use(cors());

// Todo 전체 조회
app.get("/api/todos", (req, res) => {
  setTimeout(() => res.json(todos), 1000);
});

// Todo 1개 조회
app.get("/api/todos/:id", (req, res) => {
  const todo = todos.find((t) => t.id == req.params.id);
  todo ? res.json(todo) : res.status(404).json({ error: "Todo not found" });
});

// Todo 등록
app.post("/api/todos", (req, res) => {
  const newTodo = { id: nextId++, ...req.body };
  todos.push(newTodo);
  res.json(todos);
});

// Todo 수정
app.patch("/api/todos/:id", (req, res) => {
  const id = Number(req.params.id);
  const index = todos.findIndex((t) => t.id == id);
  if (index > -1) {
    todos[index] = { ...todos[index], ...req.body };
    res.json(todos);
  } else {
    res.status(404).json({ error: "Todo not found" });
  }
});

// Todo 삭제
app.delete("/api/todos/:id", (req, res) => {
  const id = Number(req.params.id);
  todos = todos.filter((t) => t.id !== id);
  res.json(todos);
});

// Post 전체 조회
app.get("/api/posts", (req, res) => {
    setTimeout(() => res.json(posts), 1000);
  });
  
  // Post 등록
  app.post("/api/posts", (req, res) => {
    const newPost = { id: nextId++, ...req.body };
    posts.push(newPost);
    res.status(201).json(posts);
  });
  
  // Post 1개 조회
  app.get("/api/posts/:id", (req, res) => {
    const post = posts.find((p) => p.id == req.params.id);
    post ? res.json(post) : res.status(404).json({ error: "Post not found" });
  });
  
  // Post 삭제
  app.delete("/api/posts/:id", (req, res) => {
    const id = Number(req.params.id);
    posts = posts.filter((p) => p.id !== id);
    res.json(posts);
  });

// 서버 실행
app.listen(port, () => {
  console.log(`🛡️  Server listening on port: ${port} 🛡️`);
});


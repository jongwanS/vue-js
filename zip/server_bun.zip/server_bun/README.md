##### 🚀 Bun은 기존 Node.js보다 훨씬 빠르며, 패키지 관리 기능도 포함하고 있어 개발이 간편합니다!
* Bun은 자체적으로 Bun.serve() 를 제공하여 Express 없이 API를 만들 수 있습니다.

#### 📌 윈도우에서 Bun을 설치
#### windows powershell 에서 가능합니다. 
```
iwr https://bun.sh/install.ps1 -UseBasicParsing | Invoke-Expression
```

#### 📌 Bun 실행 확인 ( VSCode 재시작)
```
bun -v
```
#### 📌 Express 와 CORS 설치
```
bun install express cors
```
#### 아래와 같은 설치 오류가 발생하면 Bun 캐시를 삭제 후 재설치 
#### 📌 캐시 삭제 
* powershell에서 
```
Remove-Item -Recurse -Force "$env:USERPROFILE\.bun\install\cache"
```
```
bun install express cors
bun add v1.2.2 (c1708ea6)
error: moving "negotiator" to cache dir failed
EPERM: Operation not permitted (NtSetInformationFile())
  From: .9d7afffde72bbbfd-00000034.negotiator
    To: negotiator@0.6.3@@@1

error: InstallFailed extracting tarball from negotiator
```

### 📌 server.js 실행
```
bun run server.js
```
